# Time-to-quality benchmark

Process wall time includes launch, parsing, compilation, and warm search. Incumbent traces are observed by the parent process every 5 ms; delivery and trace overhead are included. Fixture generation is recorded separately.

References are labelled best-known unless independently established for the identical query. Default references are the maximum found by this campaign, so percentages do not certify proximity to the global optimum. Timeouts and no-result runs remain in all denominators.

| Scenario | Variant | T99 successes | T99 median (s) | No result | Completed | T99 speedup vs first arm |
|---|---|---:|---:|---:|---:|---:|
| fam_tierstack_medium | current_exact15 | 1/1 | 0.0671 | 0 | 1 | — |
| fam_tierstack_medium | wide_exact15 | 1/1 | 0.0625 | 0 | 0 | 1.07× |
| fam_tierstack_medium | current_alns15 | 2/2 | 0.0396 | 0 | 0 | 1.69× |
| fam_tierstack_medium | elite_alns15 | 2/2 | 0.0400 | 0 | 0 | 1.68× |
| fam_spellsteal_medium | current_exact15 | 0/1 | censored | 0 | 0 | — |
| fam_spellsteal_medium | wide_exact15 | 0/1 | censored | 0 | 0 | — |
| fam_spellsteal_medium | current_alns15 | 2/2 | 3.1993 | 0 | 0 | — |
| fam_spellsteal_medium | elite_alns15 | 2/2 | 0.2743 | 0 | 0 | — |
| fam_hybrid_medium | current_exact15 | 1/1 | 0.1294 | 0 | 0 | — |
| fam_hybrid_medium | wide_exact15 | 1/1 | 0.1348 | 0 | 0 | 0.96× |
| fam_hybrid_medium | current_alns15 | 2/2 | 0.1588 | 0 | 0 | 0.81× |
| fam_hybrid_medium | elite_alns15 | 2/2 | 0.0471 | 0 | 0 | 2.75× |
| fam_cancelstack_large | current_exact15 | 1/1 | 0.0681 | 0 | 0 | — |
| fam_cancelstack_large | wide_exact15 | 1/1 | 0.1182 | 0 | 0 | 0.58× |
| fam_cancelstack_large | current_alns15 | 2/2 | 0.0619 | 0 | 0 | 1.10× |
| fam_cancelstack_large | elite_alns15 | 2/2 | 0.0618 | 0 | 0 | 1.10× |
| fam_heavy_melee_large | current_exact15 | 1/1 | 0.0830 | 0 | 0 | — |
| fam_heavy_melee_large | wide_exact15 | 1/1 | 0.0779 | 0 | 0 | 1.07× |
| fam_heavy_melee_large | current_alns15 | 2/2 | 0.0496 | 0 | 0 | 1.67× |
| fam_heavy_melee_large | elite_alns15 | 2/2 | 0.0470 | 0 | 0 | 1.77× |
| meta_mage_arcanist_meteor_remove_6 | current_exact15 | 0/1 | censored | 0 | 0 | — |
| meta_mage_arcanist_meteor_remove_6 | wide_exact15 | 0/1 | censored | 0 | 0 | — |
| meta_mage_arcanist_meteor_remove_6 | current_alns15 | 2/2 | 3.8228 | 0 | 0 | — |
| meta_mage_arcanist_meteor_remove_6 | elite_alns15 | 2/2 | 2.6308 | 0 | 0 | — |
| meta_mage_light_bender_healing_remove_6 | current_exact15 | 0/1 | censored | 0 | 0 | — |
| meta_mage_light_bender_healing_remove_6 | wide_exact15 | 0/1 | censored | 0 | 0 | — |
| meta_mage_light_bender_healing_remove_6 | current_alns15 | 2/2 | 5.8296 | 0 | 0 | — |
| meta_mage_light_bender_healing_remove_6 | elite_alns15 | 2/2 | 6.4846 | 0 | 0 | — |
| spell_8free | current_exact15 | 1/1 | 0.1141 | 0 | 0 | — |
| spell_8free | wide_exact15 | 1/1 | 0.1194 | 0 | 0 | 0.96× |
| spell_8free | current_alns15 | 2/2 | 0.0631 | 0 | 0 | 1.81× |
| spell_8free | elite_alns15 | 2/2 | 0.0705 | 0 | 0 | 1.62× |

A censored T99 median means the target was not reached in at least half the runs. Speedup is omitted unless every repeat on both arms reached the same target. Completion time is never substituted for baseline T99.
