# Time-to-quality benchmark

Process wall time includes launch, parsing, compilation, and warm search. Incumbent traces are observed by the parent process every 5 ms; delivery and trace overhead are included. Fixture generation is recorded separately.

References are labelled best-known unless independently established for the identical query. Default references are the maximum found by this campaign, so percentages do not certify proximity to the global optimum. Timeouts and no-result runs remain in all denominators.

| Scenario | Variant | T99 successes | T99 median (s) | No result | Completed | T99 speedup vs first arm |
|---|---|---:|---:|---:|---:|---:|
| gaia_all_free | current_exact15 | 1/1 | 0.0569 | 0 | 0 | — |
| gaia_all_free | wide_exact15 | 1/1 | 0.0572 | 0 | 0 | 0.99× |
| gaia_all_free | current_alns15 | 2/2 | 0.1593 | 0 | 0 | 0.36× |
| gaia_all_free | elite_alns15 | 2/2 | 0.1732 | 0 | 0 | 0.33× |

A censored T99 median means the target was not reached in at least half the runs. Speedup is omitted unless every repeat on both arms reached the same target. Completion time is never substituted for baseline T99.
