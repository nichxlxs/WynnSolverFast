# Time-to-quality benchmark

Process wall time includes launch, parsing, compilation, and warm search. Incumbent traces are observed by the parent process every 5 ms; delivery and trace overhead are included. Fixture generation is recorded separately.

References are labelled best-known unless independently established for the identical query. Default references are the maximum found by this campaign, so percentages do not certify proximity to the global optimum. Timeouts and no-result runs remain in all denominators.

| Scenario | Variant | T99 successes | T99 median (s) | No result | Completed | T99 speedup vs first arm |
|---|---|---:|---:|---:|---:|---:|
| fam_tierstack_medium | current_alns15 | 2/2 | 0.0396 | 0 | 0 | — |
| fam_tierstack_medium | elite_alns15 | 2/2 | 0.0400 | 0 | 0 | 0.99× |
| fam_spellsteal_medium | current_alns15 | 2/2 | 3.1993 | 0 | 0 | — |
| fam_spellsteal_medium | elite_alns15 | 2/2 | 0.2743 | 0 | 0 | 11.66× |
| fam_hybrid_medium | current_alns15 | 2/2 | 0.1588 | 0 | 0 | — |
| fam_hybrid_medium | elite_alns15 | 2/2 | 0.0471 | 0 | 0 | 3.37× |
| fam_cancelstack_large | current_alns15 | 2/2 | 0.0619 | 0 | 0 | — |
| fam_cancelstack_large | elite_alns15 | 2/2 | 0.0618 | 0 | 0 | 1.00× |
| fam_heavy_melee_large | current_alns15 | 2/2 | 0.0496 | 0 | 0 | — |
| fam_heavy_melee_large | elite_alns15 | 2/2 | 0.0470 | 0 | 0 | 1.06× |
| meta_mage_arcanist_meteor_remove_6 | current_alns15 | 2/2 | 3.8228 | 0 | 0 | — |
| meta_mage_arcanist_meteor_remove_6 | elite_alns15 | 2/2 | 2.6308 | 0 | 0 | 1.45× |
| meta_mage_light_bender_healing_remove_6 | current_alns15 | 2/2 | 5.8296 | 0 | 0 | — |
| meta_mage_light_bender_healing_remove_6 | elite_alns15 | 2/2 | 6.4846 | 0 | 0 | 0.90× |
| spell_8free | current_alns15 | 2/2 | 0.0631 | 0 | 0 | — |
| spell_8free | elite_alns15 | 2/2 | 0.0705 | 0 | 0 | 0.90× |

A censored T99 median means the target was not reached in at least half the runs. Speedup is omitted unless every repeat on both arms reached the same target. Completion time is never substituted for baseline T99.
