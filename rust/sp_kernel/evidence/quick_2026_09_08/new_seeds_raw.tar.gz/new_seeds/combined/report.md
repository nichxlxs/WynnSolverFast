# Time-to-quality benchmark

Process wall time includes launch, parsing, compilation, and warm search. Incumbent traces are observed by the parent process every 5 ms; delivery and trace overhead are included. Fixture generation is recorded separately.

References are labelled best-known unless independently established for the identical query. Default references are the maximum found by this campaign, so percentages do not certify proximity to the global optimum. Timeouts and no-result runs remain in all denominators.

| Scenario | Variant | T99 successes | T99 median (s) | No result | Completed | T99 speedup vs first arm |
|---|---|---:|---:|---:|---:|---:|
| fam_spellsteal_medium | current_alns15 | 2/2 | 0.5404 | 0 | 0 | — |
| fam_spellsteal_medium | elite_alns15 | 2/2 | 0.8044 | 0 | 0 | 0.67× |
| meta_mage_arcanist_meteor_remove_6 | current_alns15 | 2/2 | 1.4068 | 0 | 0 | — |
| meta_mage_arcanist_meteor_remove_6 | elite_alns15 | 2/2 | 2.7289 | 0 | 0 | 0.52× |
| meta_mage_light_bender_healing_remove_6 | current_alns15 | 2/2 | 4.1437 | 0 | 0 | — |
| meta_mage_light_bender_healing_remove_6 | elite_alns15 | 2/2 | 5.1401 | 0 | 0 | 0.81× |

A censored T99 median means the target was not reached in at least half the runs. Speedup is omitted unless every repeat on both arms reached the same target. Completion time is never substituted for baseline T99.
