# Time-to-quality benchmark

Process wall time includes launch, parsing, compilation, and warm search. Incumbent traces are observed by the parent process every 5 ms; delivery and trace overhead are included. Fixture generation is recorded separately.

References are labelled best-known unless independently established for the identical query. Default references are the maximum found by this campaign, so percentages do not certify proximity to the global optimum. Timeouts and no-result runs remain in all denominators.

| Scenario | Variant | T99 successes | T99 median (s) | No result | Completed | T99 speedup vs first arm |
|---|---|---:|---:|---:|---:|---:|
| fam_cancelstack_large | current_exact15 | 1/1 | 0.0681 | 0 | 0 | — |
| fam_heavy_melee_large | current_exact15 | 1/1 | 0.0830 | 0 | 0 | — |
| meta_mage_arcanist_meteor_remove_6 | current_exact15 | 0/1 | censored | 0 | 0 | — |
| meta_mage_light_bender_healing_remove_6 | current_exact15 | 0/1 | censored | 0 | 0 | — |
| spell_8free | current_exact15 | 1/1 | 0.1141 | 0 | 0 | — |

A censored T99 median means the target was not reached in at least half the runs. Speedup is omitted unless every repeat on both arms reached the same target. Completion time is never substituted for baseline T99.
